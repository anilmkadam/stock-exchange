package com.navi.stockexchange.models;

public enum OrderType {
    BUY,
    SELL
}
