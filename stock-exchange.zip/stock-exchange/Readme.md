# Stock Exchange

## How to run application
> ./mvnw spring-boot:run -e

## ToDo
Unit test